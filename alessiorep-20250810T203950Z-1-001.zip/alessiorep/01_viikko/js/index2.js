console.log("this is a Javascript test");
alert("Sta' pâgia esta agiando!");

let cur_year = 2025;
let ab_urbe_condita = 753;

let auc_year = cur_year + ab_urbe_condita;

console.log("AUC year", auc_year);
console.log("Rôma era construitava in BC", ab_urbe_condita);

let banane = 200;
let arance = 62;
let mêle = 294;

let frùitsi = banane + arance + mêle;
console.log("La summa dil'ji frùitsi", frùitsi);

let age = 22;
let double_age = age * 2;
let half_age = age / 2;
console.log("age", age);
console.log("double age", double_age);
console.log("half age", half_age);