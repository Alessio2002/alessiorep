// Määrittele muuttuja nimeltään count alkuperäisellä arvolla 0 ja sitten lisää siihen yksi (lisää 1 siihen) seuraavalla rivillä

let count;
count++;
