// Määrittele muuttuja nimeltään ageLimit, jota ei voi uudelleen määrittää, ja anna sille arvoksi 18.
let ageLimit=18;