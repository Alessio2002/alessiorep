// Määrittele kaksi muuttujaa: student ja name.
// Anna muuttujalle name arvoksi "Mikko".
// Kopioi arvo muuttujasta name muuttujaan student.
// Tulosta student-muuttujan arvo konsoliin (tulostus on "Mikko").

let student;
let nimi = "mikko";
student = nimi;
console.log("the student's name is", student);